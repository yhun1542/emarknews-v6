module.exports = {
  info: console.log,
  error: console.error,
  warn: console.warn,
  debug: console.log
};
