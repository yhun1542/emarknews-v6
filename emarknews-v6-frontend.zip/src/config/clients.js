module.exports = {
  initialize: async () => {
    console.log('[APIClients] Initializing...');
    return {};
  },
  getAllClients: () => ({})
};
